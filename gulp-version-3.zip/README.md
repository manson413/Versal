# Gulp-start

<ul>
  <li>download ZIP</li>
  <li>command line: <strong>npm update --save-dev (npm up -D)</strong></li>
  <li>command line: <strong>npm i</strong></li>
  <li>command line: <strong>gulp</strong></li>
</ul>
<hr>
For check updates in <i>package.json</i>:<br>
&nbsp;&nbsp;&nbsp;command line: <strong>npm i -g npm-check-updates</strong><br>
use:<br>
&nbsp;&nbsp;&nbsp;command line: <strong>ncu</strong>
<br>
<br>
<strong>For svg sprites</strong>
<br>
<ul>
  <li>npm install gulp-svg-sprites gulp-svgmin gulp-cheerio gulp-replace -g</li>
  <li>npm link gulp-svg-sprites gulp-svgmin gulp-cheerio gulp-replace</li>
</ul>
<hr>





